const K='modeer_v1';
let data=JSON.parse(localStorage.getItem(K)||'{"transactions":[],"debts":[]}');
const money=n=>Number(n||0).toLocaleString('ar-EG')+' ج.م';
function save(){localStorage.setItem(K,JSON.stringify(data));render();}
function addTransaction(){
 const amount=Number(document.getElementById('amount').value), note=document.getElementById('note').value.trim();
 if(!amount)return alert('اكتب المبلغ');
 data.transactions.unshift({id:Date.now(),type:document.getElementById('type').value,amount,note,date:new Date().toLocaleDateString('ar-EG')});
 document.getElementById('amount').value='';document.getElementById('note').value='';save();
}
function addDebt(){
 const name=document.getElementById('debtName').value.trim(), amount=Number(document.getElementById('debtAmount').value), date=document.getElementById('debtDate').value;
 if(!name||!amount||!date)return alert('أكمل البيانات');
 data.debts.unshift({id:Date.now(),name,amount,date,paid:false});
 document.getElementById('debtName').value='';document.getElementById('debtAmount').value='';document.getElementById('debtDate').value='';save();
}
function toggleDebt(id){const d=data.debts.find(x=>x.id===id);if(d)d.paid=!d.paid;save();}
function render(){
 let inc=data.transactions.filter(x=>x.type==='income').reduce((a,x)=>a+x.amount,0);
 let exp=data.transactions.filter(x=>x.type==='expense').reduce((a,x)=>a+x.amount,0);
 document.getElementById('income').textContent=money(inc);document.getElementById('expense').textContent=money(exp);document.getElementById('balance').textContent=money(inc-exp);
 document.getElementById('transactions').innerHTML=data.transactions.length?data.transactions.slice(0,20).map(x=>`<div class="item ${x.type==='income'?'incomeItem':'expenseItem'}"><span>${x.note||'بدون بيان'}<small class="muted"> — ${x.date}</small></span><b>${x.type==='income'?'+':'-'}${money(x.amount)}</b></div>`).join(''):'<p class="muted">لا توجد حركات حتى الآن</p>';
 document.getElementById('debts').innerHTML=data.debts.length?data.debts.map(x=>`<div class="item"><span>${x.name}<small class="muted"> — ${x.date}</small></span><span><b>${money(x.amount)}</b> <button style="width:auto;padding:6px 10px;margin:0" onclick="toggleDebt(${x.id})">${x.paid?'تم':'تسديد'}</button></span></div>`).join(''):'<p class="muted">لا توجد أقساط</p>';
}
render();